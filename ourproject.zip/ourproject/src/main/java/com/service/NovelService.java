package com.service;

import com.entity.Novel;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface NovelService {

    //分页功能实现
    PageInfo spiltAll(int pageNum,int pageSize);

    //模糊查询，根据作者或书名,主键降序排列
    PageInfo splitFuzzy(String keyword,int pageNum,int pageSize);

    //类别查询
    PageInfo splitType(String type,int pageNum,int pageSize);

    //获取收藏书籍列表
    List<Novel> myCollection(Integer uid);

    Novel down(Integer nid);

}
