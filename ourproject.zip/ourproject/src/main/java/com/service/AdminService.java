package com.service;

import com.entity.Administrator;
import com.entity.Novel;

public interface AdminService {

    Administrator login(String name,String pwd);

    Integer addNovel(Novel novel);
}
