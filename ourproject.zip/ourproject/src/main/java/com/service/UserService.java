package com.service;

import com.entity.User;


public interface UserService {

    //查询数据库内所有用户，用于登陆判断
    User selectAll(String name,String pwd);

    //增加新用户
    Integer insertUser(String name,String pwd);

    //根据名字查询
    String selectByName(String name);

}
