package com.service.impl;

import com.dao.AdminDao;
import com.entity.Administrator;
import com.entity.Novel;
import com.service.AdminService;
import com.utils.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminDao adminDao;

    @Override
    public Administrator login(String name, String pwd) {
        //从数据库里提取所有管理员来对比
        List<Administrator> list = adminDao.selectAll();

        for(int i=0 ; i<list.size() ;i++){
            Administrator admin = list.get(i);
            if(name.equals(admin.getAname())){
                /**
                 * 密文密码
                 */
                String temp = MD5Util.getMD5(pwd);
                if(temp.equals(admin.getApwd())){
                    return admin;
                }
            }
        }
        return null;
    }

    @Override
    public Integer addNovel(Novel novel) {
        return adminDao.insertNovel(novel);
    }
}
