package com.service.impl;

import com.dao.UserDao;
import com.entity.User;
import com.service.UserService;
import com.utils.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;

    @Override
    public User selectAll(String name, String pwd) {
        //提取所有的用户账号密码
        List<User> list = userDao.selectAll();

        for(int i=0 ; i<list.size() ;i++){
            User user = list.get(i);
            if(name.equals(user.getUname())){
                String temp = MD5Util.getMD5(pwd);
                if(temp.equals(user.getUpwd())){
                    return user;
                }
            }
        }

        return null;
    }

    @Override
    public Integer insertUser(String name, String pwd) {
        return userDao.insertUser(name,pwd);
    }

    @Override
    public String selectByName(String name) {
        return userDao.selectByName(name);
    }
}
