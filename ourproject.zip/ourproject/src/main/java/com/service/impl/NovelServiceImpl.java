package com.service.impl;

import com.dao.NovelDao;
import com.entity.Novel;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.service.NovelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NovelServiceImpl implements NovelService {
    @Autowired
    private NovelDao novelDao;

    @Override
    public PageInfo spiltAll(int pageNum, int pageSize) {
        //使用分页插件工具类
        PageHelper.startPage(pageNum, pageSize);

        //按照主键降序排列（最新的在最前面）
        List<Novel> list = novelDao.selectIdOrderByDesc();

        //将查询到的集合封装
        PageInfo<Novel> pageInfo = new PageInfo<>(list);
        return pageInfo;
    }

    @Override
    public PageInfo splitFuzzy(String keyword, int pageNum, int pageSize) {
        //使用分页插件工具类
        PageHelper.startPage(pageNum, pageSize);

        //按照主键降序排列（最新的在最前面）
        String target = "%"+keyword+"%";
        List<Novel> list = novelDao.selectFuzzyIdOrderByDesc(target);

        //将查询到的集合封装
        PageInfo<Novel> pageInfo = new PageInfo<>(list);
        return pageInfo;
    }

    @Override
    public PageInfo splitType(String type, int pageNum, int pageSize) {
        //使用分页插件工具类
        PageHelper.startPage(pageNum, pageSize);

        //按照主键降序排列（最新的在最前面）
        String target = "%"+type+"%";
        List<Novel> list = novelDao.selectByType(target);

        //将查询到的集合封装
        PageInfo<Novel> pageInfo = new PageInfo<>(list);
        return pageInfo;
    }

    @Override
    public List<Novel> myCollection(Integer uid) {
        List<Integer> list = novelDao.selectCollection(uid);
        List<Novel> res = null;

        for(int i=0 ;i<list.size() ;i++){
            res.add(novelDao.selectById(list.get(i)));
        }

        return res;
    }

    @Override
    public Novel down(Integer nid) {
        return novelDao.selectById(nid);
    }


}
