package com.dao;

import com.entity.User;

import java.util.List;

public interface UserDao {

    //查询数据库内所有用户
    List<User> selectAll();

    //查询名称
    String selectByName(String name);

    //添加用户
    Integer insertUser(String name,String pwd);


}
