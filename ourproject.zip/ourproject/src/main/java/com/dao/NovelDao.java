package com.dao;

import com.entity.Novel;

import java.util.List;

public interface NovelDao {

    //查询库内所有小说封面等内容
    List<Novel> selectAll();

    //模糊查询，根据作者或书名
    List<Novel> selectFuzzy(String keyword);

    //主键降序排列查询
    List<Novel> selectIdOrderByDesc();

    //模糊查询，根据作者或书名,主键降序排列
    List<Novel> selectFuzzyIdOrderByDesc(String keyword);

    //根据类别查询
    List<Novel> selectByType(String type);

    //根据用户id查询收藏小说
    //查到的应该是小说id，再根据小说id返回小说信息
    List<Integer> selectCollection(Integer uid);

    //根据小说id查询小说
    Novel selectById(Integer nid);

}
