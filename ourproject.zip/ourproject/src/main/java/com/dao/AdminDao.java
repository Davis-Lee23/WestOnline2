package com.dao;

import com.entity.Administrator;
import com.entity.Novel;

import java.util.List;

public interface AdminDao {

    List<Administrator> selectAll();

    //添加书籍
    Integer insertNovel(Novel novel);

}
