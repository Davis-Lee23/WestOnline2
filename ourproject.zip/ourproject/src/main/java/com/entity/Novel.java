package com.entity;

public class Novel {

    private String nname;
    private String nintroduction;
    private String type;
    private String nimage;
    private String ntxt;
    private Integer nlove;
    private String nauthor;

    public String getNname() {
        return nname;
    }

    public void setNname(String nname) {
        this.nname = nname;
    }

    public String getNintroduction() {
        return nintroduction;
    }

    public void setNintroduction(String nintroduction) {
        this.nintroduction = nintroduction;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNimage() {
        return nimage;
    }

    public void setNimage(String nimage) {
        this.nimage = nimage;
    }

    public String getNtxt() {
        return ntxt;
    }

    public void setNtxt(String ntxt) {
        this.ntxt = ntxt;
    }

    public Integer getNlove() {
        return nlove;
    }

    public void setNlove(Integer nlove) {
        this.nlove = nlove;
    }

    public String getNauthor() {
        return nauthor;
    }

    public void setNauthor(String nauthor) {
        this.nauthor = nauthor;
    }

    @Override
    public String toString() {
        return "Novel{" +
                "nname='" + nname + '\'' +
                ", nintroduction='" + nintroduction + '\'' +
                ", type='" + type + '\'' +
                ", nimage='" + nimage + '\'' +
                ", ntxt='" + ntxt + '\'' +
                ", nlove=" + nlove +
                ", nauthor='" + nauthor + '\'' +
                '}';
    }
}
