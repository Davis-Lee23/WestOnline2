package com.controller;

import com.entity.Novel;
import com.github.pagehelper.PageInfo;
import com.service.NovelService;
import com.utils.FileNameUtil;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.net.URLEncoder;
import java.util.List;

@Controller
@RequestMapping("/home")
public class NovelController {
    public static final int PAGE_SIZE=5;

    @Autowired
    private NovelService novelService;

    /**
     * 展示分页内容
     * @param request
     * @return
     */
    @RequestMapping("/page")
    public String split(HttpServletRequest request){
        //显示第一页的内容
        PageInfo info = novelService.spiltAll(1,PAGE_SIZE);
        //传给前端的数据
        request.setAttribute("info",info);
        //返回一个网址
        return "";
    }

    /**
     * 分页内容回显
     * @param page 页数
     * @param session
     */
    @ResponseBody
    @RequestMapping("/ajaxpage")
    public void ajaxSplit(int page, HttpSession session){
        //取得当前page参数的页面数据
        PageInfo info = novelService.spiltAll(page,PAGE_SIZE);
        session.setAttribute("info",info);
    }


    /**
     * 根据作者和书名的模糊查询
     * @param request
     * @param keyword 输入的查询字符串
     * @return
     */
    @RequestMapping("/search")
    //从前端接收参数
    public String fuzzySpilt(HttpServletRequest request,String keyword){
        //显示第一页的内容
        PageInfo info = novelService.splitFuzzy(keyword,1,PAGE_SIZE);
        //传给前端的数据
        request.setAttribute("info",info);
        //返回一个网址
        return "result";
    }

    /**
     * 分页显示
     * @param page 页数
     * @param session
     * @param keyword 同上
     */
    @ResponseBody
    @RequestMapping("/ajaxsearch")
    public void ajaxFuzzySplit(int page, HttpSession session,String keyword){
        //取得当前page参数的页面数据
        PageInfo info = novelService.splitFuzzy(keyword,page,PAGE_SIZE);
        session.setAttribute("info",info);
    }

    /**
     * 根据类别返回小说
     * @param request
     * @param type 小说的类别
     * @return
     */
    @RequestMapping("/ranks")
    public String typeSpilt(HttpServletRequest request,String type){
        //显示第一页的内容
        PageInfo info = novelService.splitType(type,1,PAGE_SIZE);
        //传给前端的数据
        request.setAttribute("info",info);
        //返回一个网址
        return "result";
    }

    /**
     * 小说展示分页
     * @param page 页数
     * @param session
     * @param type 小说类别
     */
    @ResponseBody
    @RequestMapping("/ajaxranks")
    public void ajaxTypeSplit(int page, HttpSession session,String type){
        //取得当前page参数的页面数据
        PageInfo info = novelService.splitType(type,page,PAGE_SIZE);
        session.setAttribute("info",info);
    }

    /**
     * 用户收藏书架
     * @param uid 用户id
     * @return
     */
    @RequestMapping("/collections")
    public ModelAndView myCollection(Integer uid){
        ModelAndView mv = new ModelAndView();
        List<Novel> list = novelService.myCollection(uid);
        //返回给前端的参数
        mv.addObject("collection",list);
        //返回的网址
        mv.setViewName("");

        return mv;
    }


    /**
     * 图片回显功能
     * @param pimage 上传的图片文件
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("/ajaxImg")
    public Object ajaxImg(MultipartFile pimage,HttpServletRequest request){
        //提取生成的文件名（UUID+上传文件后缀如.jpg、.png）
        String saveImageName = FileNameUtil.getUUIDFileName() + FileNameUtil.getFileType(pimage.getOriginalFilename());
        //String saveFileName = FileNameUtil.getUUIDFileName() + FileNameUtil.getFileType(ptxt.getOriginalFilename());
        //得到项目中图片存储路径(获取真实的物理路径)
        String path = request.getServletContext().getRealPath("/store_image");
        //String path2 = request.getServletContext().getRealPath("/store_txt");
        //转存 path:D:\具体路径 || \当前文件路径 || 图片名称
        try {
            pimage.transferTo(new File(path+File.separator+saveImageName));
            System.out.println((new File(path+File.separator+saveImageName)).toString());
        } catch (IOException e) {
            e.printStackTrace();
        }

        //返回客户端Json对象，封装图片路径，实现回显
        JSONObject object = new JSONObject();
        object.put("imgurl",saveImageName);

        return object.toString();
    }

    /**
     * 下载功能
     * @param request
     * @param response
     * @param nid 书本id
     * @throws IOException
     */
    @RequestMapping("/down")
    public void down(HttpServletRequest request, HttpServletResponse response,Integer nid) throws IOException {
        Novel novel = novelService.down(nid);
        //获取文件名
        String txtName = "D:\\TheCode\\Project\\ourproject\\target\\ourproject\\store_txt\\"+novel.getNtxt();
        //设置编码
        txtName = URLEncoder.encode(txtName,"UTF-8");
        //获取输入流
        InputStream bis = new BufferedInputStream(new FileInputStream(new File(txtName)));
        //设置下载头
        response.addHeader("Content-Disposition","attachment;filename=" + txtName);
        //1.设置文件ContentType类型，这样设置，会自动判断下载文件类型
        response.setContentType("multipart/form-data");
        BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream());
        int len = 0;
        while((len = bis.read()) != -1){
            out.write(len);
            out.flush();
        }
        out.close();

    }

}
