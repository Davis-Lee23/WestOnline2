package com.controller;

import com.entity.Administrator;
import com.entity.Novel;
import com.service.AdminService;
import com.utils.FileNameUtil;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;

@Controller
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private AdminService adminService;

    //异步上传的图片名称
    String saveImageName="";

    //异步上传小说文件
    String saveFileName="";

    //实现登录判断

    /**
     * 登录验证判断
     * @param name 用户姓名
     * @param pwd 用户密码
     * @param request
     * @return
     */
    @RequestMapping("/login")
    public String login(String name, String pwd, HttpServletRequest request){
        //业务逻辑层进行判断，返回对应的管理员对象
        Administrator administrator = adminService.login(name,pwd);

        if(administrator != null){
            //数据库找的到对象，匹配成功
            request.setAttribute("admin",administrator);
            //返回到管理员界面
            return "home";
        }else {
            //登陆失败
            //返回给前端错误信息参数
            request.setAttribute("","用户名或密码错误");
            return "";
        }
    }


    /**
     * ajax实现图片回显
     * @param pimage 图片文件
     * @param ptxt 小说内容文件
     * @param request
     * @return
     */
    @ResponseBody//专门负责ajax
    @RequestMapping("/ajaxImg")
    public Object ajaxIma(MultipartFile pimage,MultipartFile ptxt,HttpServletRequest request){
        //提取生成的文件名（UUID+上传文件后缀如.jpg、.png）
        saveImageName = FileNameUtil.getUUIDFileName()+FileNameUtil.getFileType(pimage.getOriginalFilename());
        //得到项目中图片存储路径(获取真实的物理路径)
        String path = request.getServletContext().getRealPath("/store_image");
        String path2 = request.getServletContext().getRealPath("/store_txt");
        //转存 path:D:\具体路径 || \当前文件路径 || 图片名称
        try {
            pimage.transferTo(new File(path+File.separator+saveImageName));
            System.out.println((new File(path+File.separator+saveImageName)).toString());
            ptxt.transferTo(new File(path2+File.separator+saveFileName));
        } catch (IOException e) {
            e.printStackTrace();
        }

        //返回客户端Json对象，封装图片路径，实现回显
        JSONObject object = new JSONObject();
        object.put("imgurl",saveImageName);
        object.put("txturl",saveFileName);

        return object.toString();
    }

    //前端将数据传输过来，我将数据展示给他

    /**
     * @param novel 前端传入的对象属性自动封装
     * @param request
     * @return
     */
    @RequestMapping("/home ")
    public String check(Novel novel, HttpServletRequest request){
        novel.setNimage(saveImageName);
        novel.setNtxt(saveFileName);
        int num = -1;
        num = adminService.addNovel(novel);
        if(num>0){
            request.setAttribute("msg","增加成功");
        }else {
            request.setAttribute("msg","增加失败");
        }

        //图片和文件存储
        String path1 = (new File(request.getServletContext().getRealPath("/store_image")+File.separator+saveImageName)).toString();
        String path2 = (new File(request.getServletContext().getRealPath("/store_txt")+File.separator+saveFileName)).toString();

        //保存到磁盘上，略

        saveFileName = "";
        saveImageName = "";

        //重定向到主页
        return "";
    }
}
