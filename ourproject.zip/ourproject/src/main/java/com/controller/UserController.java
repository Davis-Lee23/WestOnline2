package com.controller;

import com.entity.User;
import com.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;

@Controller
public class UserController {
    @Autowired
    private UserService userService;

    /**
     * 登陆验证
     * @param name 用户姓名
     * @param pwd 用户密码
     * @param request
     */
    @RequestMapping("/login")
    public String login(String name, String pwd, HttpServletRequest request){
        User user = userService.selectAll(name,pwd);

        if(user != null){
            //数据库找的到对象，匹配成功
            request.setAttribute("admin",user);
            //返回到管理员界面
            return "";
        }else {
            //登陆失败
            //返回给前端错误信息参数
            request.setAttribute("","用户名或密码错误");
            /**
             * 有没有
             */
            return "regist";
        }
    }

    /**
     * 注册功能
     * @param name 用户姓名(重复则无法通过)
     * @param pwd 用户密码
     * @return
     */
    @RequestMapping("/regist")
    public ModelAndView insertUser(String name, String pwd){
        ModelAndView mv = new ModelAndView();
        //从数据库查询名称是否已经存在
        String temp = userService.selectByName(name);
        //返回给前端的参数提示
        String tip = "注册失败，用户名已存在";

        //这说明名称在数据库不存在
        int num = -1;
        if(temp.equals("")){
            num = userService.insertUser(name,pwd);
        }
        if(num > 0){
            tip = "用户:【"+name+"】 注册成功";
        }
        mv.addObject("tip",tip);
        mv.setViewName("result");
        return mv;
    }
}
