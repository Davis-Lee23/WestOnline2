/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50536
Source Host           : localhost:3306
Source Database       : ourproject

Target Server Type    : MYSQL
Target Server Version : 50536
File Encoding         : 65001

Date: 2022-02-27 15:00:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `novel`
-- ----------------------------
DROP TABLE IF EXISTS `novel`;
CREATE TABLE `novel` (
  `nid` int(11) NOT NULL,
  `nname` varchar(80) NOT NULL,
  `nintroduction` varchar(255) DEFAULT NULL,
  `type` varchar(40) NOT NULL,
  `nimage` varchar(255) DEFAULT NULL,
  `ntxt` varchar(255) NOT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of novel
-- ----------------------------
