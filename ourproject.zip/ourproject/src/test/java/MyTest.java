import com.utils.MD5Util;
import org.junit.Test;

public class MyTest {

    @Test
    public void myTest(){
        String s1 = MD5Util.getMD5("321");
        System.out.println(s1);
    }
}
